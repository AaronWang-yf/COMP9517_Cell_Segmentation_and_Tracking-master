from deepwater import deepwater


def evaluate():
    deepwater(mode=3)


if __name__ == '__main__':
    evaluate()
