# [marker_threshold, cell_mask_thershold]
THRESHOLDS = {
    'DIC-C2DH-HeLa': [200, 210],
    'Fluo-N2DH-SIM+': [240, 100],
    'PhC-C2DL-PSC': [120, 156]
}
