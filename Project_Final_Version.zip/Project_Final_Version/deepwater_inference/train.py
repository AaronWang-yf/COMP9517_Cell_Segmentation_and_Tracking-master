from deepwater import deepwater


def train():
    deepwater(mode=1)


if __name__ == '__main__':
    train()
