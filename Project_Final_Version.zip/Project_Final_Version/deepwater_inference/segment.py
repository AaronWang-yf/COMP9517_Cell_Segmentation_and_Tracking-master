from deepwater import deepwater


def segment():
    deepwater(mode=2)


if __name__ == '__main__':
    segment()
